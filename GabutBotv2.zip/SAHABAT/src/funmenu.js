const funmenu = (prefix) => { 
	return `
╔══✪〘 FUN 〙✪══
║
╠➥ *${prefix}tebakgambar*
╠➥ *${prefix}caklontong*
╠➥ *${prefix}family100*
╠➥ *${prefix}game*
╠➥ *${prefix}truth*
╠➥ *${prefix}dare*
╠➥ *${prefix}quotes*
╠➥ *${prefix}hilih*
╠➥ *${prefix}alay* [text]
╠➥ *${prefix}simi* [text]
╠➥ *${prefix}bucin*
╠➥ *${prefix}gtts* [text]
╠➥ *${prefix}tts*
║
╚═〘 Rizky BOT 〙`
}
exports.funmenu = funmenu